package hkhc.iperfwrapper;

/**
 * Created by herman on 27/2/2017.
 */

//Java_com_example_hellojni_HelloJni_stringFromJNI

public class HelloJni {

    public native String stringFromJNI();

}
