package hkhc.iperfwrapper;

/**
 * Created by herman on 6/3/2017.
 */

public interface DefaultConfig {

    void defaults(Iperf3 perf3);


}
